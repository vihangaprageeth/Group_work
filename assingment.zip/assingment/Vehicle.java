package assingment;

// Base abstract class BaseVehicle
abstract class BaseVehicle {
    private double distance; // in kilometers
    private double weight;   // in kilograms

    public BaseVehicle(double distance, double weight) {
        this.distance = distance;
        this.weight = weight;
    }
//Getters and Setters
    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    // Abstract method to calculate cost
    public abstract double calculateCost();
}

// Subclass Truck
class Truck extends BaseVehicle {
    public Truck(double distance, double weight) {
        super(distance, weight);
    }

    @Override
    public double calculateCost() {
        return getDistance() * 5 + getWeight() * 2;
    }
}

// Subclass Ship
class Ship extends BaseVehicle {
    public Ship(double distance, double weight) {
        super(distance, weight);
    }

    @Override
    public double calculateCost() {
        return getDistance() * 3 + getWeight() * 1.5;
    }
}

// Subclass Airplane
class Airplane extends BaseVehicle {
    public Airplane(double distance, double weight) {
        super(distance, weight);
    }

    @Override
    public double calculateCost() {
        return getDistance() * 10 + getWeight() * 5;
    }
}

// Main class to demonstrate polymorphism
public class Vehicle {
    public static void main(String[] args) {
        // Create a list of BaseVehicle objects
        BaseVehicle[] vehicles = {
            new Truck(100, 500),
            new Ship(200, 1000),
            new Airplane(150, 300)
        };

        // Calculate and display transport cost for each vehicle
        for (BaseVehicle vehicle : vehicles) {
            System.out.println("Transport cost for " + vehicle.getClass().getSimpleName() +
                               ": $" + vehicle.calculateCost());
        }
    }
}
