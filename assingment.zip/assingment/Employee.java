package assingment;


public class Employee {
    private int id;
    private String name;
    private String department;
    private double salary;

    public Employee(int id, String name, String department, double salary) {
        if (id <= 0) {
            throw new IllegalArgumentException("Employee ID must be a positive integer.");
        }
        if (salary < 0) {
            throw new IllegalArgumentException("Salary cannot be less than zero.");
        }
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSalary(double salary) {
        if (salary < 0) {
            throw new IllegalArgumentException("Salary cannot be less than zero.");
        }
        this.salary = salary;
    }

    public double getBonus() {
        return salary * 0.10;
    }
}

class EmployeeManagement {
    public static void main(String[] args) {
        Employee emp1 = new Employee(1, "John Doe", "Engineering", 50000);
        System.out.println("Employee ID: " + emp1.getId());
        System.out.println("Employee Name: " + emp1.getName());
        System.out.println("Employee Department: " + emp1.getDepartment());
        System.out.println("Employee Bonus: " + emp1.getBonus());

        emp1.setName("Jane Doe");
        emp1.setDepartment("Marketing");
        emp1.setSalary(60000);
        System.out.println("Updated Employee Name: " + emp1.getName());
        System.out.println("Updated Employee Department: " + emp1.getDepartment());
        System.out.println("Updated Employee Bonus: " + emp1.getBonus());
    }
}
