package assingment;

 public class Employee
{
    // attributes

    protected int empID;
    protected String empName;
    protected String empDepartment;
    protected double empSalary;

    // constructor

    public Employee(int empID, String empName, String empDepartment, double empSalary)
    {
    this.empID = empID;
    this.empName = empName;
    this.empDepartment = empDepartment;
    this.empSalary = empSalary;
    }

    // getter

    public int getEmpID()
    {
        return empID;
    }

    public String getEmpName()
    {
        return empName;
    }

    public String getEmpDepartment()
    {
        return empDepartment;
    }
 
    public double getEmpSalary()
    {
        return empSalary;
    }

    // setter

    public void setEmpID(int empID)
    {
        this.empID = empID;
    }

    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public void setEmpDepartment(String empDepartment)
    {
        this.empDepartment = empDepartment;
    }

    public void setEmpSalary(double empSalary)
    {
        if (empSalary > 0)
        {
            this.empSalary = empSalary;
        }
        else
        {
            System.out.println("Invalid Salary");
            
        }
    }

    // discount

    public void findDiscount()
    {
        double discount = empSalary * 0.1;
        System.out.println("Salary with Discount is : " + discount);
    }

    // total salary

    public void totalSalary()
    {
        double totalSalary = empSalary + (empSalary * 0.1);
        System.out.println("Total Salary is : " + totalSalary);
    }

    // display details

    public void displayDetails()
    {
        System.out.println("Employee ID : " + empID);
        System.out.println("Employee Name : " + empName);
        System.out.println("Employee Department : " + empDepartment);
        System.out.println("Employee Salary : " + empSalary);
    }
    
    // public static void main(String[] args) {
    //     Employee obj = new Employee(1, "Adhi", "IT", 50000);
    //     obj.displayDetails();
    //     obj.findDiscount();
    // }

static class Manager extends Employee {
    

    public Manager(int empID, String empName, String empDepartment, double empSalary) {
        super(empID, empName, empDepartment, empSalary);
        
    }

    public static void main(String[] args) {
        Manager manager = new Manager(3, "Charlie", "Sales", 70000);
        manager.displayDetails();
        manager.findDiscount();
        manager.totalSalary();
    }
}
}
