package assingment;

import assingment.Shipment.DomesticShipment;
import assingment.Shipment.InternationalShipment;

class Shipment
{
    private int shipmentID;
    private double shipmentWeight;
    private String shipmentDestination;

    //constructor

    public Shipment(int shipmentID, double shipmentWeight, String shipmentDestination)
    {
        this.shipmentID = shipmentID;
        this.shipmentWeight = shipmentWeight;
        this.shipmentDestination = shipmentDestination;
    }

    //getter

    public int getShipmentID()
    {
        return shipmentID;
    }

    public double getShipmentWeight()
    {
        return shipmentWeight;
    }

    public String getShipmentDestination()
    {
        return shipmentDestination;
    }

    //setter

    public void setShipmentID(int shipmentID)
    {
        this.shipmentID = shipmentID;
    }

    public void setShipmentWeight(double shipmentWeight)
    {
        this.shipmentWeight = shipmentWeight;
    }

    public void setShipmentDestination(String shipmentDestination)
    {
        this.shipmentDestination = shipmentDestination;
    }

    public double calculateTotalCost(double baseCost) {
        return baseCost;
    }

    //method

    //domestic shipment

    class DomesticShipment extends Shipment
    {
        private String distance;

        public DomesticShipment(int shipmentID, double shipmentWeight, String shipmentDestination)
        {
            super(shipmentID, shipmentWeight, shipmentDestination);
            this.distance = distance;
        }

        public String getDistance ()
        {
            return distance;
        }

        public void setDistance(String distance)
        {
            this.distance = distance;
        }

        //overriding calculateTotalCost method
        @Override
        public double calculateTotalCost(double baseCost)
        {
            double tax = baseCost * 0.05; 
            return baseCost + tax;
        }
    }

    //international shipment

    class InternationalShipment extends Shipment {
        private double customsFee;
        private double insuranceFee;
    
        // Constructor
        public InternationalShipment(int shipmentID, double shipmentWeight, String shipmentDestination, double customsFee, double insuranceFee) {
            super(shipmentID, shipmentWeight, shipmentDestination);
            this.customsFee = customsFee;
            this.insuranceFee = insuranceFee;
        }
    
        // Getters and Setters
        public double getCustomsFee() {
            return customsFee;
        }
    
        public void setCustomsFee(double customsFee) {
            this.customsFee = customsFee;
        }
    
        public double getInsuranceFee() {
            return insuranceFee;
        }
    
        public void setInsuranceFee(double insuranceFee) {
            this.insuranceFee = insuranceFee;
        }
    
        // Override calculateTotalCost method
        @Override
        public double calculateTotalCost(double baseCost) {
            double tax = 0.15 * baseCost;
            return baseCost + tax + customsFee + insuranceFee;
        }
    }

}

    //main method

public class ShipmentTest
{
    public static void main(String[] args) {
        // Create a DomesticShipment instance
        Shipment shipment = new Shipment(0, 0, "");
        DomesticShipment domesticShipment = shipment.new DomesticShipment(1, 50.0, "New York");
        domesticShipment.setDistance("North");
        double domesticBaseCost = 100.0; // Example base cost
        double domesticTotalCost = domesticShipment.calculateTotalCost(domesticBaseCost);
        System.out.println("Domestic Shipment Total Cost: $" + domesticTotalCost);

        // Create an InternationalShipment instance
        InternationalShipment internationalShipment = shipment.new InternationalShipment(2, 70.0, "London", 50.0, 30.0);
        double internationalBaseCost = 200.0; // Example base cost
        double internationalTotalCost = internationalShipment.calculateTotalCost(internationalBaseCost);
        System.out.println("International Shipment Total Cost: $" + internationalTotalCost);
    }
    
}